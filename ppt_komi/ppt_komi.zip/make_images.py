"""Генерация фоновых изображений для презентации «Моря Республики Коми».

Все картинки рисуются процедурно (numpy + Pillow): градиенты, свечение,
силуэты берега, волны, зерно. Никаких внешних ресурсов.
"""
from __future__ import annotations

import numpy as np
from PIL import Image, ImageFilter

OUT = "img"
SS = 2  # суперсэмплинг


# ----------------------------------------------------------------------------- utils
def _grid(w: int, h: int):
    yy, xx = np.mgrid[0:h, 0:w].astype(np.float32)
    return xx / w, yy / h


def vgrad(h: int, w: int, stops):
    """Вертикальный градиент по списку (y_frac, rgb)."""
    ys = np.linspace(0.0, 1.0, h, dtype=np.float32)
    out = np.zeros((h, 3), dtype=np.float32)
    for i in range(len(stops) - 1):
        y0, c0 = stops[i]
        y1, c1 = stops[i + 1]
        m = (ys >= y0) & (ys <= y1)
        if not m.any():
            continue
        t = ((ys[m] - y0) / max(y1 - y0, 1e-6))[:, None]
        out[m] = np.array(c0, np.float32) * (1 - t) + np.array(c1, np.float32) * t
    return np.repeat(out[:, None, :], w, axis=1)


def ridge(w: int, base: float, amp: float, seed: int, octaves: int = 5):
    rng = np.random.default_rng(seed)
    x = np.linspace(0.0, 1.0, w, dtype=np.float32)
    y = np.zeros(w, dtype=np.float32)
    a = 1.0
    for o in range(octaves):
        f = 2 ** o
        y += a * np.sin(2 * np.pi * f * x + rng.uniform(0, 6.283))
        y += 0.45 * a * np.sin(2 * np.pi * f * 1.7 * x + rng.uniform(0, 6.283))
        a *= 0.5
    y = y / (np.abs(y).max() + 1e-9)
    return base + y * amp


def grain(img: np.ndarray, amount: float = 2.0, seed: int = 1) -> np.ndarray:
    rng = np.random.default_rng(seed)
    n = rng.normal(0.0, amount, img.shape[:2]).astype(np.float32)
    return img + n[..., None]


def vignette(img: np.ndarray, strength: float = 0.42, power: float = 2.2) -> np.ndarray:
    h, w = img.shape[:2]
    X, Y = _grid(w, h)
    d = np.sqrt(((X - 0.5) * 1.15) ** 2 + ((Y - 0.5) * 1.0) ** 2) / 0.72
    v = 1.0 - strength * np.clip(d, 0, 1) ** power
    return img * v[..., None]


def to_img(arr: np.ndarray) -> Image.Image:
    return Image.fromarray(np.clip(arr, 0, 255).astype(np.uint8), "RGB")


def downsample(img: Image.Image, w: int, h: int) -> Image.Image:
    return img.resize((w, h), Image.LANCZOS)


def blend(img: np.ndarray, mask: np.ndarray, color, alpha: float = 1.0) -> np.ndarray:
    a = (mask.astype(np.float32) * alpha)[..., None]
    c = np.array(color, np.float32)[None, None, :]
    return img * (1 - a) + c * a


# ----------------------------------------------------------------------------- seascape
def seascape(w: int, h: int, pal: dict, seed: int = 0) -> Image.Image:
    W, H = w * SS, h * SS
    horizon = pal.get("horizon", 0.60)
    X, Y = _grid(W, H)

    sky = vgrad(H, W, pal["sky"])
    water = vgrad(H, W, pal["water"])
    mask_water = (Y >= horizon)[..., None]
    img = sky * (1 - mask_water) + water * mask_water

    # свечение у горизонта
    cx, cy = pal.get("sun", (0.66, horizon))
    rad = np.sqrt(((X - cx) * 1.0) ** 2 + ((Y - cy) * pal.get("glow_aspect", 1.5)) ** 2)
    glow = np.exp(-(rad / pal.get("glow_sigma", 0.34)) ** 2)
    img += glow[..., None] * np.array(pal["glow"], np.float32) * pal.get("glow_power", 0.85)

    # диск солнца / луны
    if pal.get("sun_r"):
        r = pal["sun_r"]
        d = np.sqrt(((X - cx) * 1.0) ** 2 + ((Y - cy) * 1.0) ** 2)
        disc = np.clip((r - d) / (r * 0.45), 0, 1) ** 0.8
        img = img * (1 - disc[..., None] * 0.9) + np.array(pal["sun_color"], np.float32) * (disc[..., None] * 0.9)

    # дальний берег + ближний берег
    for layer in pal.get("ridges", []):
        base = horizon + layer["dz"]
        ry = ridge(W, base, layer["amp"], seed + layer["seed"])
        m = (Y >= ry[None, :]) & (Y < horizon + 0.012) if layer["dz"] <= 0 else (Y >= ry[None, :])
        img = blend(img, m, layer["color"], layer.get("alpha", 1.0))

    # отражение солнца на воде
    if pal.get("reflection", True):
        wmask = (Y > horizon).astype(np.float32)
        depth = np.clip((Y - horizon) / (1 - horizon), 0, 1)
        wob = 0.055 + 0.16 * depth
        col = np.exp(-(((X - cx) / wob) ** 2) * 1.9)
        streaks = 0.45 + 0.55 * np.abs(np.sin(depth * 120 + 3.0 * np.sin(X * 9.0)))
        img += (col * streaks * wmask * depth ** 0.6)[..., None] * np.array(
            pal.get("glow", (255, 240, 220)), np.float32
        ) * pal.get("refl_power", 0.75)

    # волны
    for i, wave in enumerate(pal.get("waves", [])):
        y0 = horizon + wave["dz"]
        yy = y0 + wave["amp"] * np.sin(2 * np.pi * wave["f"] * X + wave["phase"])
        m = Y >= yy
        img = blend(img, m, wave["color"], wave.get("alpha", 0.5))

    # дымка над горизонтом
    haze = np.exp(-(((Y - horizon) / pal.get("haze_sigma", 0.05)) ** 2))
    img += (haze * pal.get("haze_power", 0.16))[..., None] * np.array(pal.get("glow", (200, 230, 255)), np.float32)

    img = grain(img, pal.get("grain", 2.2), seed + 17)
    img = vignette(img, pal.get("vignette", 0.45))
    return downsample(to_img(img), w, h)


# ----------------------------------------------------------------------------- flat backgrounds
def flat_bg(w: int, h: int, pal: dict, seed: int = 3) -> Image.Image:
    W, H = w * SS, h * SS
    X, Y = _grid(W, H)
    img = vgrad(H, W, pal["grad"])

    for blob in pal.get("blobs", []):
        bx, by, r, col, p = blob
        d = np.sqrt(((X - bx) * pal.get("aspect", 1.0)) ** 2 + (Y - by) ** 2)
        g = np.exp(-(d / r) ** 2) * p
        img += g[..., None] * np.array(col, np.float32)

    # тонкие волновые линии
    for line in pal.get("lines", []):
        y0, amp, f, col, thick, p, count, step = line
        for k in range(count):
            off = k * step
            curve = y0 + off + amp * np.sin(2 * np.pi * f * X + k * 0.9)
            m = np.abs(Y - curve) < thick
            img = blend(img, m, col, p)

    img = grain(img, pal.get("grain", 1.8), seed)
    img = vignette(img, pal.get("vignette", 0.25))
    return downsample(to_img(img), w, h)


def scrim(w: int, h: int, direction: str = "left", start=0.97, end=0.0, color=(5, 14, 24)) -> Image.Image:
    W, H = w, h
    X, Y = _grid(W, H)
    if direction == "left":
        t = np.clip((0.80 - X) / 0.80, 0, 1) ** 0.85
    elif direction == "bottom":
        t = np.clip((0.95 - Y) / 0.62, 0, 1) ** 1.05
    else:  # right
        t = np.clip((X - 0.20) / 0.80, 0, 1) ** 0.85
    a = (t * (start - end) + end) * 255
    rgba = np.zeros((H, W, 4), np.uint8)
    rgba[..., 0] = color[0]
    rgba[..., 1] = color[1]
    rgba[..., 2] = color[2]
    rgba[..., 3] = np.clip(a, 0, 255).astype(np.uint8)
    return Image.fromarray(rgba, "RGBA")


# ----------------------------------------------------------------------------- палитры
TEAL = dict(
    horizon=0.62,
    sky=[(0.0, (3, 11, 22)), (0.34, (6, 30, 46)), (0.62, (18, 78, 92))],
    water=[(0.62, (14, 62, 76)), (0.82, (8, 38, 52)), (1.0, (2, 8, 16))],
    glow=(96, 232, 214),
    glow_power=0.55,
    glow_sigma=0.42,
    glow_aspect=1.7,
    sun=(0.70, 0.575),
    sun_r=0.019,
    sun_color=(226, 255, 246),
    ridges=[
        dict(dz=-0.030, amp=0.030, seed=2, color=(9, 40, 52), alpha=0.85),
        dict(dz=-0.016, amp=0.020, seed=7, color=(6, 27, 37), alpha=0.95),
    ],
    waves=[
        dict(dz=0.045, amp=0.006, f=3.0, phase=0.4, color=(10, 52, 66), alpha=0.55),
        dict(dz=0.115, amp=0.009, f=2.2, phase=1.7, color=(7, 38, 50), alpha=0.6),
        dict(dz=0.230, amp=0.013, f=1.6, phase=3.1, color=(4, 24, 34), alpha=0.7),
        dict(dz=0.420, amp=0.018, f=1.1, phase=5.0, color=(2, 15, 23), alpha=0.8),
    ],
    haze_power=0.13,
    grain=2.4,
    vignette=0.5,
)

INDIGO = dict(
    horizon=0.58,
    sky=[(0.0, (7, 9, 26)), (0.36, (16, 20, 54)), (0.58, (58, 52, 96))],
    water=[(0.58, (42, 44, 84)), (0.80, (18, 20, 44)), (1.0, (4, 6, 16))],
    glow=(228, 186, 150),
    glow_power=0.75,
    glow_sigma=0.30,
    glow_aspect=1.6,
    sun=(0.30, 0.545),
    sun_r=0.014,
    sun_color=(255, 236, 210),
    ridges=[
        dict(dz=-0.022, amp=0.034, seed=11, color=(34, 32, 60), alpha=0.9),
        dict(dz=-0.010, amp=0.018, seed=5, color=(20, 20, 42), alpha=0.95),
    ],
    waves=[
        dict(dz=0.055, amp=0.008, f=2.6, phase=0.9, color=(30, 32, 66), alpha=0.55),
        dict(dz=0.140, amp=0.011, f=1.9, phase=2.4, color=(20, 22, 50), alpha=0.62),
        dict(dz=0.300, amp=0.015, f=1.3, phase=4.2, color=(12, 13, 34), alpha=0.72),
        dict(dz=0.500, amp=0.020, f=1.0, phase=5.6, color=(5, 6, 18), alpha=0.82),
    ],
    haze_power=0.10,
    grain=2.2,
    vignette=0.52,
)

GOLD = dict(
    horizon=0.60,
    sky=[(0.0, (18, 12, 14)), (0.30, (48, 26, 24)), (0.60, (140, 84, 48))],
    water=[(0.60, (120, 76, 44)), (0.80, (60, 36, 26)), (1.0, (14, 8, 8))],
    glow=(255, 196, 128),
    glow_power=0.9,
    glow_sigma=0.36,
    glow_aspect=1.7,
    sun=(0.72, 0.560),
    sun_r=0.026,
    sun_color=(255, 226, 178),
    ridges=[
        dict(dz=-0.026, amp=0.028, seed=13, color=(70, 42, 30), alpha=0.85),
        dict(dz=-0.012, amp=0.016, seed=9, color=(44, 26, 20), alpha=0.92),
    ],
    waves=[
        dict(dz=0.050, amp=0.007, f=3.2, phase=0.6, color=(96, 62, 38), alpha=0.5),
        dict(dz=0.130, amp=0.011, f=2.1, phase=2.1, color=(66, 40, 26), alpha=0.6),
        dict(dz=0.290, amp=0.016, f=1.4, phase=4.4, color=(38, 22, 16), alpha=0.72),
        dict(dz=0.480, amp=0.020, f=1.0, phase=5.9, color=(16, 9, 8), alpha=0.82),
    ],
    haze_power=0.18,
    grain=2.6,
    vignette=0.5,
)

ICE = dict(
    horizon=0.55,
    sky=[(0.0, (10, 22, 34)), (0.30, (26, 52, 68)), (0.55, (132, 176, 190))],
    water=[(0.55, (118, 158, 172)), (0.78, (56, 88, 104)), (1.0, (14, 26, 36))],
    glow=(214, 240, 246),
    glow_power=0.85,
    glow_sigma=0.44,
    glow_aspect=2.0,
    sun=(0.42, 0.512),
    sun_r=0.012,
    sun_color=(255, 255, 252),
    ridges=[
        dict(dz=-0.018, amp=0.020, seed=21, color=(70, 96, 110), alpha=0.7),
        dict(dz=-0.008, amp=0.012, seed=15, color=(46, 68, 82), alpha=0.8),
    ],
    waves=[
        dict(dz=0.045, amp=0.006, f=2.8, phase=1.2, color=(88, 122, 138), alpha=0.5),
        dict(dz=0.120, amp=0.010, f=2.0, phase=3.0, color=(60, 92, 108), alpha=0.6),
        dict(dz=0.280, amp=0.014, f=1.4, phase=4.8, color=(34, 58, 72), alpha=0.7),
        dict(dz=0.470, amp=0.019, f=1.0, phase=6.2, color=(16, 32, 44), alpha=0.8),
    ],
    haze_power=0.22,
    grain=2.0,
    vignette=0.45,
)

DEEP = dict(
    horizon=0.64,
    sky=[(0.0, (2, 8, 18)), (0.36, (5, 20, 38)), (0.64, (12, 52, 84))],
    water=[(0.64, (10, 46, 74)), (0.84, (6, 28, 48)), (1.0, (1, 6, 14))],
    glow=(120, 196, 255),
    glow_power=0.6,
    glow_sigma=0.40,
    glow_aspect=1.8,
    sun=(0.36, 0.598),
    sun_r=0.016,
    sun_color=(236, 248, 255),
    ridges=[
        dict(dz=-0.024, amp=0.026, seed=23, color=(10, 38, 58), alpha=0.85),
        dict(dz=-0.011, amp=0.016, seed=31, color=(6, 24, 40), alpha=0.95),
    ],
    waves=[
        dict(dz=0.050, amp=0.007, f=3.1, phase=0.2, color=(9, 42, 66), alpha=0.55),
        dict(dz=0.135, amp=0.010, f=2.3, phase=2.0, color=(7, 30, 50), alpha=0.62),
        dict(dz=0.300, amp=0.014, f=1.5, phase=4.6, color=(4, 18, 32), alpha=0.72),
        dict(dz=0.490, amp=0.019, f=1.0, phase=6.0, color=(2, 9, 18), alpha=0.82),
    ],
    haze_power=0.14,
    grain=2.3,
    vignette=0.5,
)

DARK_FLAT = dict(
    grad=[(0.0, (4, 11, 20)), (0.45, (5, 16, 29)), (1.0, (3, 9, 17))],
    aspect=1.0,
    blobs=[
        (0.88, 0.10, 0.55, (10, 46, 60), 0.30),
        (0.10, 0.92, 0.50, (8, 34, 48), 0.22),
    ],
    lines=[(0.90, 0.012, 0.55, (60, 150, 158), 0.0012, 0.055, 7, 0.045)],
    grain=1.6,
    vignette=0.30,
)

LIGHT_FLAT = dict(
    grad=[(0.0, (244, 250, 252)), (0.55, (231, 243, 246)), (1.0, (214, 232, 238))],
    aspect=1.0,
    blobs=[
        (0.92, 0.02, 0.62, (128, 205, 200), 0.42),
        (0.04, 0.98, 0.58, (146, 192, 216), 0.34),
        (0.45, 0.55, 0.75, (255, 255, 255), 0.30),
    ],
    lines=[(1.00, 0.016, 0.55, (96, 158, 166), 0.0016, 0.20, 7, 0.052)],
    grain=1.1,
    vignette=0.16,
)


def main() -> None:
    W, H = 1920, 1080
    jobs = {
        "hero_teal.png": lambda: seascape(W, H, TEAL, seed=1),
        "sea_deep.png": lambda: seascape(W, H, DEEP, seed=2),
        "sea_indigo.png": lambda: seascape(W, H, INDIGO, seed=3),
        "sea_gold.png": lambda: seascape(W, H, GOLD, seed=4),
        "sea_ice.png": lambda: seascape(W, H, ICE, seed=5),
        "bg_dark.png": lambda: flat_bg(W, H, DARK_FLAT, seed=6),
        "bg_light.png": lambda: flat_bg(W, H, LIGHT_FLAT, seed=7),
        "scrim_left.png": lambda: scrim(W, H, "left", 0.98, 0.0),
        "scrim_bottom.png": lambda: scrim(W, H, "bottom", 0.95, 0.0),
        "scrim_right.png": lambda: scrim(W, H, "right", 0.95, 0.0),
    }
    for name, fn in jobs.items():
        img = fn()
        img.save(f"{OUT}/{name}")
        print("ok", name, img.size, img.mode)


if __name__ == "__main__":
    main()
